package org.firstinspires.ftc.teamcode.ultimate_goal;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraRotation;

import java.util.ArrayList;

@Autonomous(name = "Tardis_UG_Autonomous", group = "Autonomous")

public class Tardis_UG_Autonomous extends AutoBaseTB1 {

    ArrayList<String> steps = new ArrayList<>();
    //creates list of steps to be completed

    double targetZoneX = 0;
    double targetZoneY = 0;
    String zoneName = "A";
    //initializes target zone variables, sets default target zone

    public void CreateSteps() {
        steps.add("Test");
        //steps.add("ROTATE_PS1");
        //steps.add("ROTATE_PS2");
        //steps.add("ROTATE_PS3");
 /*          steps.add("COUNT_RINGS");
           steps.add("MOVE_AWAY_FROM_WALL");
           steps.add("READ_ARM_POSITION");
           steps.add("MOVE_ARM_OUT_OF_WAY");
           steps.add("GO_WAYPOINT_1");
           steps.add("WAIT");
           steps.add("SHOOT_RING");
           steps.add("SHOOT_RING");
           steps.add("SHOOT_RING");
           steps.add("IDLE_SHOOTER");
           steps.add("DRIVE_TO_TZ_WAYPOINT");
           steps.add("DRIVE_TO_TZ");
           steps.add("READ_ARM_POSITION");
           steps.add("DELIVER_WOBBLE");
           steps.add("GO_TO_LAUNCH_LINE");
           steps.add("SET_FOR_TELE");*/
           steps.add("STOP");
    }


    @Override
    public void runOpMode() {//Start of the initiation for autonomous

        boolean done = false;
        CreateSteps();

        //Init functions
        defineComponents();

        double targetX = 0;
        double targetY = 0;
        double targetTheta = 0;
        double distanceTolerance = 2;
        double rotationTolerance = 4;
        int armStartPosition =  mA.getCurrentPosition();
        int armStopPosition;
        int numberOfRings = -1;
        double rotationAngle = 0;
        int armMotion = 0;
        boolean limitTriggered = false;
        double tolerance = 1;
        //instance fields/global variables

        ////////////////setting robot in initialization, readies robot for autonomous  /////////////
        //counts number of rings using vision recognition program
        pipeline = new CountRings.SkystoneDeterminationPipeline();
        webcam.setPipeline(pipeline);
        webcam.openCameraDeviceAsync(new OpenCvCamera.AsyncCameraOpenListener()
        {
            @Override
            public void onOpened()
            {
                webcam.startStreaming(320,240, OpenCvCameraRotation.SIDEWAYS_LEFT);
            }
        });

        //setting wrist and gripper to start position
        sW.setPosition(1);
        sG.setPosition(0.5);

        while (!opModeIsActive() && !isStopRequested()){
            //adds vision recognition telemetry for debug and check
            telemetry.addData("Rings", CountRings.getCount());
            telemetry.addData("Anti-Oranginess", pipeline.getAnalysis());
            telemetry.update();
            numberOfRings = CountRings.getCount();
        }

        ////////////////above code runs in initialization, readies robot for autonomous  /////////////

        waitForStart();

        //Reset time variables
        runtime.reset();

        // loops through all steps the robot is supposed to perform
        for (String currentStep : steps) {
            done = false;      // reset so we can run the next step...

            // decides which step we are on, and runs that action
            while (opModeIsActive() && (done == false)) {
                telemetry.addData("gyro", "" + String.format("%.2f deg", gyroZ));
                telemetry.addData("current position x", "" + String.format("%.2f in.", pose.x));
                telemetry.addData("current position y", "" + String.format("%.2f in.", pose.y));
                telemetry.addData("arm position", mA.getCurrentPosition());
                telemetry.addData("wrist position", sW.getPosition());
                telemetry.addData("gripper position", sG.getPosition());
                telemetry.addData("current step", currentStep);
                telemetry.addData("runtime two", runtimeTwo);
                telemetry.update();
                //Update global sensor values
                updatePoseStrafe();
                gyroUpdate();

                switch (currentStep) {

                    case "Test" :
                        /*targetX = 0;
                        targetY = 12;
                        targetTheta = 0;
                        done = (moveToLocation(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance));*/
                        moveToPose(0, 12, 0, 50);
                        break;

                    case "SET_FOR_TELE":
                        //sets arm and elevator for the start of tele-op
                        goToAngle(0);  //moves elevator
                        sLower.setPosition(1);
                        if(frontLimit.isPressed()) {  //uses limit switch to move arm to a known position
                            limitTriggered = true;
                            armStartPosition = mA.getCurrentPosition();
                            }

                        else if (!limitTriggered) {

                            sW.setPosition(0); //sets position of wrist
                            mA.setPower(-1);
                             }

                            if (limitTriggered) {
                                armMotion = 3500;
                                armStopPosition = armStartPosition + armMotion; //calculates end arm position

                                if (mA.getCurrentPosition() >= armStopPosition) {

                                    mA.setPower(0);
                                    done = true;
                                    changeStep();
                                } else {
                                    mA.setPower(1);
                                }


                            }
                        break;

                    case "MOVE_AWAY_FROM_WALL":
                        //moves robot a short distance from wall to avoid the elevator contacting the wall
                        targetX = 0;
                        targetY = 3;
                        targetTheta = 0;
                        done = (moveToLocation(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance));
                        break;

                    case "LOWER_INTAKE":
                        //lowers the intake ramp to prepare for the intake of rings
                        sLower.setPosition(1);
                        done = true;
                        changeStep();
                        break;

                    case "MOVE_ARM_OUT_OF_WAY":
                        //raises arm so that it doesn't get in the way of the shooting rings
                        armMotion = 1591;
                        armStopPosition = armStartPosition - armMotion;

                        if(mA.getCurrentPosition() <= armStopPosition) {
                            mA.setPower(0);
                            done = true;
                            changeStep();
                        }
                        else {
                            mA.setPower(-1);
                        }
                        break;

                    case "COUNT_RINGS":
                        //changes the target zone that the robot moves to based on the number of rings counted during initialization
                        if (numberOfRings == 0) {
                            zoneName = "A";
                        } else if (numberOfRings == 1) {
                            zoneName = "B";
                        } else {
                            zoneName = "C";
                        }
                        changeTargetZone(zoneName);
                        done = true;
                        break;

                    case "IDLE_SHOOTER":
                        //idles shooter motor after robot is done shooting
                        mS.setPower(0.25);
                        if(runtime.seconds() > 1) {
                            done = true;
                            changeStep();
                        }
                        break;

                    case "ROTATE_PS1":
                        //rotates to power shot 1
                        targetX = 0;
                        targetY = 0;
                        targetTheta = -45;
                        done = (moveToLocation(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance));
                        /*rotationAngle = 60;
                        tolerance = 1;
                        gyroAdjust(-0.5, rotationAngle);
                        if (Math.abs(gyroZ - rotationAngle) < tolerance) {
                            done = true;
                            changeStep();
                        }
                        */
                       break;

                    case "ROTATE_PS2":
                        targetX = 0;
                        targetY = 0;
                        targetTheta = 0;
                        done = (moveToLocation(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance));
                        //rotates to power shot 2

                        break;

                    case "ROTATE_PS3":
                        targetX = 0;
                        targetY = 0;
                        targetTheta = 45;
                        done = (moveToLocation(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance));
                        //rotates to power shot 3

                        break;

                    case "SHOOT_RING":
                        //shoots rings for power shots
                        boolean doneShooting = false;
                        if(runtime.seconds() < 1) {
                            //fires ring
                            sP.setPosition(0.5);
                        }
                        else if(runtime.seconds() > 2 && runtime.seconds() < 3) {
                            //resets trigger
                            sP.setPosition(0);
                        }
                        else if(runtime.seconds() > 3) {
                            //changes step
                            done = true;
                            changeStep();
                        }
                        break;

                    case "DELIVER_WOBBLE":
                        // drops wobble in target zone
                        armMotion = 2000;
                        armStopPosition = armStartPosition - armMotion;
                        double delayTime = 2;
                        if(mA.getCurrentPosition() <= armStopPosition) {

                            mA.setPower(0);

                            if(runtime.seconds() > delayTime && runtime.seconds() < (delayTime + .5)) {

                                sW.setPosition(0.3);
                            }
                            if(runtime.seconds() > (delayTime + .5) && runtime.seconds() < (delayTime + 1)) {

                                sG.setPosition(0.8);
                            }

                            if(runtime.seconds() > (delayTime + 1)) {

                                done = true;
                                changeStep();
                            }
                        }
                        else {
                            mA.setPower(-1);
                        }
                        break;

                    case "DRIVE_TO_TZ":
                        //moves to target zone
                        targetX = targetZoneX;
                        targetY = targetZoneY;
                        targetTheta = -90;
                        done = (moveToLocation(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance));
                        break;

                    case "DRIVE_TO_TZ_WAYPOINT":
                        //moves to way point based on the location of the target zone
                        targetX = targetZoneX - 24;
                        targetY = targetZoneY;
                        targetTheta = -90;
                        done = (moveToLocation(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance));
                        break;

                    case "GO_WAYPOINT_1":
                        //goes to a known location to shoot power shots from, moves elevator to shooting position
                        int idealElevAngle = 30;

                        targetX = 0;
                        targetY = 48;
                        targetTheta = 0;


                        goToAngle(idealElevAngle);
                        mS.setPower(1);

                        if(getElevAngle(potentiometer.getVoltage()) > idealElevAngle-5){
                            done = (moveToLocation(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance));
                            if(done){
                                mE.setPower(0);
                            }
                        }


                        break;

                    case "WAIT":
                        //wait step that can be added in if necessary for a debug of the code
                        if(runtime.seconds() > 0 && runtime.seconds() < 1) {
                            done = false;
                        }
                        else {
                            done = true;
                            changeStep();
                        }
                        break;

                    case "READ_ARM_POSITION":
                        //reads arm encoder position for future steps
                        armStartPosition = mA.getCurrentPosition();
                        done = true;
                        break;

                    case "GO_TO_LAUNCH_LINE":
                        //goes to launch line at the very end of autonomous
                        targetX = 0;
                        targetY = 72;
                        targetTheta = 0;
                        done = (moveToLocation(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance));
                        break;

                    case "STOP":
                        //stops drive train
                        drive(0, 0, 0);
                        done = true;
                        break;

                }
            }
        }
        shutdown();
    }

    public boolean moveToLocation
            //function for setting a point with odometry, changes step when robot position is in a certain tolerance
            (double targetX, double targetY, double targetTheta, double distanceTolerance, double rotationTolerance) {
        if (isInTolerance(targetX, targetY, targetTheta, distanceTolerance, rotationTolerance)) {
            changeStep(); // you are within tolerance, so stop the drive train and move to next step
            return true;
        } else {
            telemetry.addData("target X", targetX);
            telemetry.addData("target Y", targetY);
            moveToPose(targetX, targetY, targetTheta, 50);
            return false;
        }

    }

    public void changeTargetZone (String zoneName){
        //sets coordinates for all three target zones, target zone is chosen depending on number of rings counted
        switch (zoneName) {

            case "A":
                targetZoneX = 20;
                targetZoneY = 68;
                break;

            case "B":
                targetZoneX = 2;
                targetZoneY = 92;
                break;

            case "C":
                targetZoneX = 22;
                targetZoneY = 106;
                break;

            default:
                targetZoneX = 0;
                targetZoneY = 0;
                break;

        }
    }
}





