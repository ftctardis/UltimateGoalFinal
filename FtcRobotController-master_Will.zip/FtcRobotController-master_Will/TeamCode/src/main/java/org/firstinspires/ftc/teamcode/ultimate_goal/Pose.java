package org.firstinspires.ftc.teamcode.ultimate_goal;

public class Pose {

    double x;
    double y;
    double theta;

    public Pose(double inputX, double inputY, double inputTheta) {
        this.x = inputX;
        this.y = inputY;
        this.theta = inputTheta;
    }

}