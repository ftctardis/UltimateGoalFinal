package org.firstinspires.ftc.teamcode.ultimate_goal;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

@TeleOp(name = "Tardis_UG_TeleOp", group = "Linear Opmode")

public class Tardis_UG_TeleOp extends BaseClassTB1 {    // LinearOpMode {

    private ElapsedTime runtime = new ElapsedTime();
//    private DcMotor mFL = null;
//   private DcMotor mFR = null;
// changed motor names in entire program to mFL and mFR from mL and mR

    @Override
    public void runOpMode() {

        // Initialize the hardware variables. Note that the strings used here as parameters
        // to 'get' must correspond to the names assigned during the robot configuration
        // step (using the FTC Robot Controller app on the phone).

        defineComponents();
        double wristPosition = 0.5;
        boolean shooterMotorIdle = true;
        boolean previousB2State = false;
        boolean motorPowerFast = false;
        double powerMultiplier = 0.6;
        boolean previousBState = false;
        boolean amIFiring = false;
        double george = 0;

        telemetry.addData("Status", "Initialized");
        telemetry.update();

        waitForStart();

        while (opModeIsActive()) {
            george = potentiometer.getVoltage();
            telemetry.addData("arm position", mA.getCurrentPosition());
            telemetry.addData("wrist position", "" + String.format("%.2f", wristPosition));
            telemetry.addData("potentiometer angle", getElevAngle(george));
            telemetry.addData("potentiometer voltage", george);
            telemetry.addData("gripper position", sG.getPosition());
            telemetry.addData("fire ring", sP.getPosition());
            telemetry.addData("current position x", "" + String.format("%.2f in.", pose.x));
            telemetry.addData("current position y", "" + String.format("%.2f in.", pose.y));
            telemetry.addData("front limit", frontLimit.isPressed());
            telemetry.addData("back limit", backLimit.isPressed());
            telemetry.update();
            //Update global sensor values
            updatePoseStrafe();
            gyroUpdate();

            //Gamepad 1 Variables
            waitForStart();
            runtime.reset();
            double leftY1 = gamepad1.left_stick_y * powerMultiplier;
            double rightX1 = -(gamepad1.right_stick_x) / 2;
            double leftX1 = -(gamepad1.left_stick_x) * powerMultiplier;
            double rightY1 = -(gamepad1.right_stick_y);
            double rightTrigger = (gamepad1.right_trigger);
            double leftTrigger = -(gamepad1.left_trigger);
            boolean xButton = (gamepad1.x);
            //Gamepad 2 Variables
            double rightTrigger2 = (gamepad2.right_trigger);
            double rightY2 = (gamepad2.right_stick_y);
            double leftY2 = (gamepad2.left_stick_y);
            double leftTrigger2 = (gamepad2.left_trigger);
            boolean leftBumper = (gamepad2.left_bumper);
            boolean rightBumper = (gamepad2.right_bumper);
            boolean bButton2 = (gamepad2.b);
            boolean aButton = (gamepad2.a);
            boolean bButton = (gamepad1.b);
            boolean yButton = (gamepad1.y);
            boolean xButton2 = (gamepad2.x);


            telemetry.addData("leftY2", leftY2);

            //set shooter position
            if (yButton) {
                goToAngle(30);
                moveToPose(0, -24, -10, 50);
            } else {
                drive(leftY1, leftX1, rightX1);

            }

            if(getElevAngle(george) <= 0){
                mE.setPower(0);
            }

            //moves arm to position for wobble pick up
            if(xButton2) {
                sW.setPosition(0.4);
                if(frontLimit.isPressed()) {
                    mA.setPower(0);
                    wristPosition = 0.36;
                }

                else if (!frontLimit.isPressed()) {
                    mA.setPower(-1);
                }
            }

            //arm
            if(!xButton2) {

                mA.setPower(rightY2);
            }

            //changes drive speed
            if (bButton != previousBState && bButton) {
                if (motorPowerFast) {
                    motorPowerFast = false;
                    powerMultiplier = 1;
                } else {
                    motorPowerFast = true;
                    powerMultiplier = 0.6;
                }
            }


            //potentiometer/elevator set angle

            if (aButton && !yButton) {
                goToAngle(30);
            } else if(!yButton && getElevAngle(george) > 2){
                    mE.setPower(leftY2);
            }else if(getElevAngle(george) < 2&& leftY2 < 1){
                mE.setPower(leftY2);
            }

            //intake - negative is pulling in, positive is spitting out
            // goToAngle sets elevator to level that+ is optimal for intake of rings
            if ((rightTrigger != 0) && (leftTrigger != 0)) {
                mI.setPower(0);
            } else if ((leftTrigger != 0) && (sLower.getPosition() == 1)) {
                mI.setPower(-1);
                goToAngle(0);
            } else if ((rightTrigger != 0) && (sLower.getPosition() == 1)) {
                mI.setPower(1);
                goToAngle(0);
            } else {
                mI.setPower(0);
            }


            //code to fire a ring

//            if (leftTrigger2 != 0) {
//                amIFiring = true;
//            }
//
//            if (sP.getPosition() >= 0.98) {
//                amIFiring = false;
//            }
//
//            if (amIFiring) {
//                sP.setPosition(1);
//            } else {
//                sP.setPosition(0);
//            }

            if (leftTrigger2 != 0) {
                sP.setPosition(1);
            } else {
                sP.setPosition(0);
            }

            // this should only run once each time b button is pressed
            if (bButton2 != previousB2State && bButton2) {
                if (shooterMotorIdle) {
                    shooterMotorIdle = false;
                    mS.setPower(1);
                } else {
                    shooterMotorIdle = true;
                    mS.setPower(0.25);
                }
            }

            //controls wrist
            if(!xButton2) {
                if (rightBumper && wristPosition < 1) {
                    wristPosition += .008;
                } else if (leftBumper && wristPosition > 0) {
                    wristPosition -= .008;
                }
                sW.setPosition(Range.clip(wristPosition, 0.3, 1));
            }

            //controls gripper (pressed = closed, released = open)
            if (rightTrigger2 != 0){
                telemetry.addData("Gripper Active", rightTrigger2);
                sG.setPosition(0.5); //sets gripper to closed
            } else {
                telemetry.addData("Gripper Inactive", rightTrigger2);
                sG.setPosition(0.8); //sets gripper to open
            }

            //controls release of intake ramp
            if (xButton) {
                sLower.setPosition(1); //released
            }
            /*else{
                sLower.setPosition(0); //default, secured
            }*/


            previousBState = bButton;
            previousB2State = bButton2;


        }
    }


}

